import Hero from "@/components/hero";
import Stats from "@/components/stats";
import WorldMap from "@/components/world-map";
import ContinentGrid from "@/components/continent-grid";
import Features from "@/components/features";
import { getGlobalStats, getContinentsOverview } from "@/lib/dashboard";

export const dynamic = "force-dynamic";

export default async function HomePage() {
  const [stats, continents] = await Promise.all([
    getGlobalStats(),
    getContinentsOverview(),
  ]);

  return (
    <div className="flex flex-1 flex-col bg-white">
      <Hero />
      <Stats stats={stats} />

      <section id="world-map" className="bg-slate-50 py-20 sm:py-28">
        <div className="mx-auto max-w-6xl px-6">
          <div className="mx-auto max-w-2xl text-center">
            <h2 className="text-3xl font-semibold tracking-tight text-slate-900 sm:text-4xl">
              A community around the world
            </h2>
            <p className="mt-4 text-lg text-slate-500">
              Un aperçu des villes où la diaspora gabonaise se retrouve déjà
              sur GabonConnect.
            </p>
          </div>

          <div className="mt-12">
            <WorldMap />
          </div>
        </div>
      </section>

      <ContinentGrid continents={continents} />
      <Features />
    </div>
  );
}
