import type { Metadata } from "next";
import { redirect } from "next/navigation";
import Link from "next/link";
import { MapPin } from "lucide-react";
import Breadcrumb from "@/components/explore/breadcrumb";
import { getCurrentUser } from "@/lib/auth";
import { prisma } from "@/lib/prisma";
import { ProfileVisibility } from "@/app/generated/prisma/client";
import { updateProfileAction } from "./actions";

export const dynamic = "force-dynamic";

export const metadata: Metadata = {
  title: "My profile | GabonConnect",
};

const ERROR_MESSAGES: Record<string, string> = {
  validation: "Please check the form and try again.",
  save_failed: "We couldn't save your changes. Please try again.",
};

interface MyProfilePageProps {
  searchParams: Promise<Record<string, string | string[] | undefined>>;
}

function first(value: string | string[] | undefined): string | undefined {
  return Array.isArray(value) ? value[0] : value;
}

export default async function MyProfilePage({ searchParams }: MyProfilePageProps) {
  // Route protégée : pas de session Supabase → connexion.
  const user = await getCurrentUser();

  if (!user) {
    redirect("/login");
  }

  const profile = await prisma.profile.findUnique({
    where: { userId: user.id },
    select: {
      id: true,
      firstName: true,
      lastName: true,
      profession: true,
      bio: true,
      visibility: true,
      city: {
        select: {
          name: true,
          country: { select: { name: true } },
        },
      },
    },
  });

  // Compte authentifié, mais pas encore de profil (inscription interrompue
  // en cours de route) : on l'envoie finir /join/profile plutôt que de
  // montrer une page vide.
  if (!profile) {
    redirect("/join/profile");
  }

  const sp = await searchParams;
  const errorCode = first(sp.error);
  const saved = first(sp.saved) === "1";

  return (
    <div className="flex flex-1 flex-col bg-slate-50">
      <section className="border-b border-slate-100 bg-white">
        <div className="mx-auto max-w-xl px-6 py-10">
          <Breadcrumb items={[{ label: "Home", href: "/" }, { label: "My profile" }]} />

          <h1 className="mt-6 text-3xl font-semibold tracking-tight text-slate-900">
            {profile.firstName} {profile.lastName}
          </h1>
          {profile.profession && (
            <p className="mt-1 text-sm text-slate-500">{profile.profession}</p>
          )}
          {profile.city && (
            <p className="mt-1 flex items-center gap-1.5 text-sm text-slate-500">
              <MapPin className="h-4 w-4 text-emerald-600" aria-hidden />
              {profile.city.name}, {profile.city.country.name}
            </p>
          )}

          {profile.visibility === ProfileVisibility.PUBLIC && (
            <Link
              href={`/members/${profile.id}`}
              className="mt-3 inline-flex items-center text-sm font-medium text-emerald-600 hover:text-emerald-700"
            >
              View my public profile →
            </Link>
          )}
        </div>
      </section>

      <div className="mx-auto w-full max-w-xl px-6 py-12">
        {saved && (
          <p className="mb-6 rounded-xl border border-emerald-200 bg-emerald-50 px-4 py-3 text-sm text-emerald-700">
            Your profile has been updated.
          </p>
        )}

        {errorCode && (
          <p
            role="alert"
            className="mb-6 rounded-xl border border-red-200 bg-red-50 px-4 py-3 text-sm text-red-700"
          >
            {ERROR_MESSAGES[errorCode] ?? ERROR_MESSAGES.validation}
          </p>
        )}

        <form
          action={updateProfileAction}
          className="flex flex-col gap-6 rounded-2xl border border-slate-200 bg-white p-6"
        >
          <p className="text-xs text-slate-400">
            First name, last name and location aren&apos;t editable yet — that&apos;s
            coming in a future update.
          </p>

          <div className="flex flex-col gap-1.5">
            <label htmlFor="profession" className="text-sm font-medium text-slate-700">
              Profession
            </label>
            <input
              id="profession"
              name="profession"
              type="text"
              maxLength={160}
              defaultValue={profile.profession ?? ""}
              placeholder="e.g. Software Engineer"
              className="w-full rounded-lg border border-slate-200 px-4 py-2.5 text-sm text-slate-900 placeholder:text-slate-400 focus:border-emerald-400 focus:outline-none focus:ring-2 focus:ring-emerald-100"
            />
          </div>

          <div className="flex flex-col gap-1.5">
            <label htmlFor="bio" className="text-sm font-medium text-slate-700">
              Bio
            </label>
            <textarea
              id="bio"
              name="bio"
              rows={4}
              maxLength={1000}
              defaultValue={profile.bio ?? ""}
              placeholder="A few words about you…"
              className="w-full resize-none rounded-lg border border-slate-200 px-4 py-2.5 text-sm text-slate-900 placeholder:text-slate-400 focus:border-emerald-400 focus:outline-none focus:ring-2 focus:ring-emerald-100"
            />
          </div>

          <fieldset className="flex flex-col gap-3">
            <legend className="text-sm font-medium text-slate-700">Visibility</legend>

            <label className="flex cursor-pointer items-start gap-3 rounded-xl border border-slate-200 p-4 has-[:checked]:border-emerald-300 has-[:checked]:bg-emerald-50">
              <input
                type="radio"
                name="visibility"
                value="PUBLIC"
                defaultChecked={profile.visibility === ProfileVisibility.PUBLIC}
                className="mt-1 h-4 w-4 accent-emerald-500"
              />
              <span>
                <span className="block text-sm font-medium text-slate-900">Public</span>
                <span className="block text-xs text-slate-500">
                  Your profile can appear in the public GabonConnect directory.
                </span>
              </span>
            </label>

            <label className="flex cursor-pointer items-start gap-3 rounded-xl border border-slate-200 p-4 has-[:checked]:border-emerald-300 has-[:checked]:bg-emerald-50">
              <input
                type="radio"
                name="visibility"
                value="PRIVATE"
                defaultChecked={profile.visibility === ProfileVisibility.PRIVATE}
                className="mt-1 h-4 w-4 accent-emerald-500"
              />
              <span>
                <span className="block text-sm font-medium text-slate-900">Private</span>
                <span className="block text-xs text-slate-500">
                  Your profile will not be visible publicly.
                </span>
              </span>
            </label>
          </fieldset>

          <button
            type="submit"
            className="mt-2 inline-flex items-center justify-center rounded-full bg-emerald-500 px-6 py-2.5 text-sm font-semibold text-slate-950 transition-colors hover:bg-emerald-400"
          >
            Save changes
          </button>
        </form>
      </div>
    </div>
  );
}
